import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

export default function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Welcome to the Doctor Appointment App</Text>
      <Button title="Schedule Appointment" onPress={() => navigation.navigate('Schedule')} />
      <Button title="View Appointments" onPress={() => navigation.navigate('Appointments')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  title: { fontSize: 24, marginBottom: 20 }
});
