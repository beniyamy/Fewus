import express from 'express';
import { createAppointment, getAppointments } from '../models/Appointment.js';

const router = express.Router();

router.get('/', async (req, res) => {
  const appointments = await getAppointments();
  res.json(appointments);
});

router.post('/', async (req, res) => {
  const { patient_id, doctor_id, date, time } = req.body;
  const appointment = await createAppointment(patient_id, doctor_id, date, time);
  res.json(appointment);
});

export default router;
