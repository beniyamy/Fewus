CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL
);

CREATE TABLE IF NOT EXISTS appointments (
    id SERIAL PRIMARY KEY,
    patient_id INTEGER REFERENCES users(id),
    doctor_id INTEGER REFERENCES users(id),
    date DATE NOT NULL,
    time TIME NOT NULL
);

INSERT INTO users (username, password, role) VALUES
('patient1', '$2b$12$nzAHPRs1CkokyYhJWzTh1OzMrtYJA4rr/Ar9P.8CVYWxr.fW13Dl.', 'patient'),
('doctor1', '$2b$12$Tj4mupjFrbKG.K10efypseBfwzKGAZ0.eIZWPSy.hKBR6QRLl1gc2', 'doctor');
