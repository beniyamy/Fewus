import pool from '../config/db.js';

export const createAppointment = async (patient_id, doctor_id, date, time) => {
  const result = await pool.query(
    'INSERT INTO appointments (patient_id, doctor_id, date, time) VALUES ($1, $2, $3, $4) RETURNING *',
    [patient_id, doctor_id, date, time]
  );
  return result.rows[0];
};

export const getAppointments = async () => {
  const result = await pool.query('SELECT * FROM appointments ORDER BY date, time');
  return result.rows;
};
